<?php /* @var $post \WP_Post */ ?>

<?php if (!empty($post)) :?>
	<div class="relink">
		<h4 class="relink-title">Read more:</h4>
		<a class="relink-link" href="<?php echo get_the_permalink($post); ?>">
			<?php echo get_the_title($post); ?>
		</a>
	</div>
<? endif; ?>
