=== Relink ===
Contributors: nechehin
Tags: link, post link, shortcode, read more, incut
Requires at least: 4.6
Tested up to: 4.9.5
Stable tag: trunk
Requires PHP: 5.4

Insert links to other posts in content as shortcode and render it with custom template.
Default template located at wp-content/plugins/relink/templates/readmore.php


== Screenshots ==

1. Button in tinymce editor
2. Insert shortcode form
3. Default link template


== Frequently Asked Questions ==

= How to use custom template =

Create filter "relink_template" and return path to your template.

Example, include template from my theme folder:

add_filter('relink_template', function(){
	return locate_template('templates/my-custom-relink-template.php');
});


== Changelog ==

= 1.2 =
* Add version param to relink-tinymce plugin url

= 1.1 =
* Add search post ID by post link

= 1.0 =
* Initial release.